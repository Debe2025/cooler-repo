
# placeholder AddonSignals-compatible stub
# real add-on would provide full API; here we only satisfy imports for Netflix if it doesn't use it deeply

def sendSignal(*args, **kwargs):
    pass

def registerSlot(*args, **kwargs):
    pass

def unregisterSlot(*args, **kwargs):
    pass
